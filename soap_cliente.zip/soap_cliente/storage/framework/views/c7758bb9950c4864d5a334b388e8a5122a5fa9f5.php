
<?php $__env->startSection('titulo', $form_edit ? 'Cliente SOAP | Editar Registro' : 'Cliente SOAP | Nueva Alta'); ?>
<?php $__env->startSection('contenido'); ?>
<div class="col-12 mb-3">
    <h2><?php echo e($form_edit ? 'Editar Registro' : 'Nueva ALta'); ?></h2>
</div>
<div class="col-lg-12">
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e($form_edit ? route('actualizar', $articulo["id"]) : route('guardar')); ?>" method="POST" class="form_files row" id="form_datos" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="col-12 col-md-12 mb-3">
                    <label for="modelo">Modelo</label>
                    <input type="text" class="form-control form-control-lg" name="modelo" id="modelo" value="<?php echo e($form_edit ? $articulo["modelo"] : old("modelo")); ?>">
                    <?php $__errorArgs = ['modelo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback d-block"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
                <div class="col-12 col-md-12 mb-3">
                    <label for="pulgadas">Pulgadas</label>
                    <input type="text" class="form-control form-control-lg" name="pulgadas" id="pulgadas" value="<?php echo e($form_edit ? $articulo["pulgadas"] : old("pulgadas")); ?>">
                    <?php $__errorArgs = ['pulgadas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback d-block"></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
                <div class="col-12 col-md-12 mb-3">
                    <label for="ram">RAM</label>
                    <input type="text" class="form-control form-control-lg" name="ram" id="ram" value="<?php echo e($form_edit ? $articulo["ram"] : old("ram")); ?>">
                    <?php $__errorArgs = ['ram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback d-block"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
                <div class="col-12 col-md-12 mb-3">
                    <label for="almacenamiento">Almacenamiento</label>
                    <input type="text" class="form-control form-control-lg" name="almacenamiento" id="almacenamiento" value="<?php echo e($form_edit ? $articulo["almacenamiento"] : old("almacenamiento")); ?>">
                    <?php $__errorArgs = ['almacenamiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback d-block"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
                
                <div class="col-12 col-md-12 text-center">
                    <a class="btn btn-danger btn-lg" href="<?php echo e(route('index')); ?>">Cancelar</a>

                    <input class="btn btn-success btn-lg" type="submit" value="<?php echo e($form_edit ? "Actualizar" : "Guardar"); ?>">
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\soap_cliente\resources\views/forms/captura.blade.php ENDPATH**/ ?>