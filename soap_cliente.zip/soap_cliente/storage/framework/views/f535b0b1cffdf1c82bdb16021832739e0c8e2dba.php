<?php $__env->startSection('titulo', 'Cliente SOAP | Inicio'); ?>
<?php $__env->startSection('contenido'); ?>
    <div class="col-12 col-md-9 mb-5">
        <h2>Computadoras</h2>
    </div>
    <div class="col-12 col-md-3 mb-5">
        <a class="btn btn-success text-white w-100" href="<?php echo e(route('nuevo')); ?>">Nueva Alta</a>
    </div>
    <div class="col-12">
        <table class="table table-responsive table-bordered" id="computadoras" data-url="<?php echo e(route('listar')); ?>">
        <thead>
            <tr>
                <th scope="col" class="text-center" style="width: 4%">#</th>
                <th scope="col" class="text-center" style="width: 16%">Modelo</th>
                <th scope="col" class="text-center" style="width: 20%">Pulgadas</th>
                <th scope="col" class="text-center" style="width: 20%">RAM</th>
                <th scope="col" class="text-center" style="width: 20%">Almacenamiento</th>
                <th scope="col" class="text-center" style="width: 20%">Opciones</th>

            </tr>
        </thead>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\soap_cliente\resources\views/index.blade.php ENDPATH**/ ?>