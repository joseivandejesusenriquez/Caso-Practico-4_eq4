<?php

Route::get('/', 'WebController@index')->name('index');
Route::get('nuevo', 'WebController@nuevo')->name('nuevo');
Route::get('editar/{id}', 'WebController@editar')->name('editar');

Route::post('guardar', 'WebController@guardar')->name('guardar');
Route::post('actualizar/{id}', 'WebController@actualizar')->name('actualizar');
Route::post('eliminar', 'WebController@eliminar')->name('eliminar');
Route::post('listado', 'WebController@listado')->name('listar');
