$(document).ready(function () {
    $('#computadoras').DataTable({
        responsive: true,
        ajax: {
            url: $("#computadoras").data('url'),
            dataType: "json",
            type: "POST",
            data: {
                _token: $("meta[name='csrf-token'] ").attr('content')
            }
        },
        language: {
            url: "https://cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json"
        },
        columns: [{ 
            "data": "id" 
        }, { 
            "data": "modelo" 
        }, { 
            "data": "pulgadas" 
        }, { 
            "data": "ram" 
        }, { 
            "data": "almacenamiento" 
        }, { 
            "data": "btn",
            "orderable": false 
        }],
        order: [[0, "desc"]]
    });
});