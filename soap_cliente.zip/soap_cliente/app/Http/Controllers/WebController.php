<?php

namespace App\Http\Controllers;

use DataTables;
use nusoap_client;
use Illuminate\Http\Request;

class WebController extends Controller
{
    private $cliente;
    
    function __construct()
    {
        
        $this->cliente = new nusoap_client(env('SOAP_CLIENT', NULL), env('SOAP_TYPE', NULL));
        $err = $this->cliente->getError();
        if ($err) {	echo 'Error en Constructor' . $err ; }
    }

    public function index()
    {
        return view('index');
    }

    public function nuevo()
    {
        return view('forms.captura',[
            'form_edit' => false
        ]);
    }

    public function editar($id)
    {
        $editar = NULL;
        $datos = $this->cliente->call('ConsultarCompu');
        foreach($datos as $item)
        {
            if($id == $item["id"])
            {
                $editar = $item;
                break;
            }
        }

        if(is_null($editar))
        {
            abort(404);
        }

        return view('forms.captura',[
            'form_edit'     => true,
            'articulo'      => $editar
        ]);
    }

    public function guardar(Request $request)
    {
        $this->validate($request,[
            'modelo'            =>'required',
            'pulgadas'          =>'required',
            'ram'               =>'required',
            'almacenamiento'    =>'required',
        ], [
            'modelo.required'           => 'Proporcione el modelo',
            'pulgadas.required'         => 'Proporcione las pulgadas',
            'ram.required'              => 'Proporcione la cantidad de memoria RAM',
            'almacenamiento.required'   => 'Proporcione la cantidad de memoria de almacenamiento',
        ]);

        $enviar = array(
            'modelo'            => $request->modelo,
            'pulgadas'          => $request->pulgadas,
            'ram'               => $request->ram,
            'almacenamiento'    => $request->almacenamiento,
        );

        $respuesta = $this->cliente->call('insertCompu', $enviar);
        if($respuesta)
        {
            return redirect()->route('index')->with('mensaje', 'Registro guardado');
        }else{
            return redirect()->route('index')->with('mensaje', 'Ocurrio un error durante el guardado');
            
        }
    }

    public function actualizar(Request $request, $id)
    {
        $this->validate($request,[
            'modelo'            =>'required',
            'pulgadas'          =>'required',
            'ram'               =>'required',
            'almacenamiento'    =>'required',
        ], [
            'modelo.required'           => 'Proporcione el modelo',
            'pulgadas.required'         => 'Proporcione las pulgadas',
            'ram.required'              => 'Proporcione la cantidad de memoria RAM',
            'almacenamiento.required'   => 'Proporcione la cantidad de memoria de almacenamiento',
        ]);

        $enviar = array(
            'id_computadora'    => $id,
            'modelo'            => $request->modelo,
            'pulgadas'          => $request->pulgadas,
            'ram'               => $request->ram,
            'almacenamiento'    => $request->almacenamiento,
        );

        $respuesta = $this->cliente->call('UpdateCompu', $enviar);
        if($respuesta)
        {
            return redirect()->route('index')->with('mensaje', 'Registro actualizado');
        }else{
            return redirect()->route('index')->with('mensaje', 'Ocurrio un error durante la actualización');
        }
    }

    public function eliminar(Request $request)
    {
        $this->validate($request,[
            'id'        =>'required',
        ], [
            'id.required'   => 'Proporcione el ID del elemento',
        ]);
        $enviar = array('id_computadora' => $request->id);

        $respuesta = $this->cliente->call('EliminarCompu', $enviar);
        if($respuesta)
        {
            return redirect()->route('index')->with('mensaje', 'Registro eliminado');
        }else{
            return redirect()->route('index')->with('mensaje', 'Ocurrio un error durante la eliminación');
        }
    }

    public function listado()
    {
        $datos = $this->cliente->call('ConsultarCompu');
        return DataTables::of($datos)
        ->addColumn('btn', function($datos){
            $boton = "
            <a class='btn btn-info text-white w-100 mb-2' href='".route('editar', $datos['id'])."'>Editar</a>
            <form action='".route('eliminar')."' method='POST'>
                <input type='hidden' name='_token' value='".csrf_token()."'>
                <input type='hidden' name='id' value='".$datos['id']."'>
                <button class='btn btn-danger text-white w-100 mb-2' type='submit'>Eliminar</button>
            </form>";
            return $boton;
        })
        ->rawColumns(['btn'])
        ->toJson();;
    }
}
