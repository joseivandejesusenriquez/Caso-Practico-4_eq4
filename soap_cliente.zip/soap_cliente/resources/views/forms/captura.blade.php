@extends('layouts.web')
@section('titulo', $form_edit ? 'Cliente SOAP | Editar Registro' : 'Cliente SOAP | Nueva Alta')
@section('contenido')
<div class="col-12 mb-3">
    <h2>{{$form_edit ? 'Editar Registro' : 'Nueva ALta'}}</h2>
</div>
<div class="col-lg-12">
    <div class="card">
        <div class="card-body">
            <form action="{{$form_edit ? route('actualizar', $articulo["id"]) : route('guardar')}}" method="POST" class="form_files row" id="form_datos" enctype="multipart/form-data">
                @csrf
                <div class="col-12 col-md-12 mb-3">
                    <label for="modelo">Modelo</label>
                    <input type="text" class="form-control form-control-lg" name="modelo" id="modelo" value="{{ $form_edit ? $articulo["modelo"] : old("modelo") }}">
                    @error('modelo')
                    <span class="invalid-feedback d-block">{{$message}}</span>
                    @enderror

                </div>
                <div class="col-12 col-md-12 mb-3">
                    <label for="pulgadas">Pulgadas</label>
                    <input type="text" class="form-control form-control-lg" name="pulgadas" id="pulgadas" value="{{ $form_edit ? $articulo["pulgadas"] : old("pulgadas") }}">
                    @error('pulgadas')
                    <span class="invalid-feedback d-block"></span>
                    @enderror

                </div>
                <div class="col-12 col-md-12 mb-3">
                    <label for="ram">RAM</label>
                    <input type="text" class="form-control form-control-lg" name="ram" id="ram" value="{{ $form_edit ? $articulo["ram"] : old("ram") }}">
                    @error('ram')
                    <span class="invalid-feedback d-block">{{$message}}</span>
                    @enderror

                </div>
                <div class="col-12 col-md-12 mb-3">
                    <label for="almacenamiento">Almacenamiento</label>
                    <input type="text" class="form-control form-control-lg" name="almacenamiento" id="almacenamiento" value="{{ $form_edit ? $articulo["almacenamiento"] : old("almacenamiento") }}">
                    @error('almacenamiento')
                    <span class="invalid-feedback d-block">{{$message}}</span>
                    @enderror

                </div>
                
                <div class="col-12 col-md-12 text-center">
                    <a class="btn btn-danger btn-lg" href="{{route('index')}}">Cancelar</a>

                    <input class="btn btn-success btn-lg" type="submit" value="{{$form_edit ? "Actualizar" : "Guardar" }}">
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
