@extends('layouts.web')
@section('titulo', 'Cliente SOAP | Inicio')
@section('contenido')
    <div class="col-12 col-md-9 mb-5">
        <h2>Computadoras</h2>
    </div>
    <div class="col-12 col-md-3 mb-5">
        <a class="btn btn-success text-white w-100" href="{{route('nuevo')}}">Nueva Alta</a>
    </div>
    <div class="col-12">
        <table class="table table-responsive table-bordered" id="computadoras" data-url="{{route('listar')}}">
        <thead>
            <tr>
                <th scope="col" class="text-center" style="width: 4%">#</th>
                <th scope="col" class="text-center" style="width: 16%">Modelo</th>
                <th scope="col" class="text-center" style="width: 20%">Pulgadas</th>
                <th scope="col" class="text-center" style="width: 20%">RAM</th>
                <th scope="col" class="text-center" style="width: 20%">Almacenamiento</th>
                <th scope="col" class="text-center" style="width: 20%">Opciones</th>

            </tr>
        </thead>
        </table>
    </div>
@endsection